=== Simple Copy ===
Contributors: Ivan Popov
Tags: backup
Stable tag: 1.0.0

This is a super simple WordPress plugin for taking backups.

== Description ==

This is a super simple WordPress plugin for taking backups.


== Installation and use ==

1. Upload the entire 'simplecopy' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0.0 =
* Initial Release - 24.04.2019
